#ifndef __PROC_STATUS_H
#define __PROC_STATUS_H
extern char *status(proc_t * task);
#endif
