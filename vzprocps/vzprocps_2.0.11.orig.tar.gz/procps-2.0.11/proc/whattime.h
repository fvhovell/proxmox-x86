/*
 * whattime.h - whattime.c declarations
 */

#ifndef __WHATTIME_H
#define __WHATTIME_H

extern void print_uptime(void);

#endif /* __WHATTIME_H */
